<?php
function remove_spaces($string) {
    return strtolower(str_replace(' ', '', $string));
}

function youhealit_get_services(): array {
    static $services = null;
    if ($services === null) {
        $path = get_stylesheet_directory() . '/includes/services-data.php';
        if (!file_exists($path)) {
            $path = get_template_directory() . '/includes/services-data.php';
        }
        $services = file_exists($path) ? require $path : [];
    }
    return $services;
}
?>
