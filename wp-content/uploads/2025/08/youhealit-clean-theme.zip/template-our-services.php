<?php
/* Template Name: Our Services Page */
?>
<?php 
/*
Template Name: Our Services
*/

get_header(); 

// Define services array (since $available_services might not exist)
function get_wellness_services() {
    return [
        [
            'name' => 'Chiropractic Care',
            'description' => 'Expert spinal adjustments and therapeutic treatments to restore proper alignment and reduce pain. Our licensed chiropractors use gentle, effective techniques to help your body heal naturally.'
        ],
        [
            'name' => 'Massage Therapy',
            'description' => 'Therapeutic massage for pain relief, relaxation, and improved circulation. Our certified massage therapists offer various techniques including deep tissue, Swedish, and trigger point therapy.'
        ],
        [
            'name' => 'Nutritional Consulting',
            'description' => 'Personalized nutrition plans for optimal health and wellness. Our nutritional experts help you develop sustainable eating habits that support your health goals and lifestyle.'
        ],
        [
            'name' => 'Acupuncture',
            'description' => 'Traditional Chinese medicine technique using fine needles to stimulate healing points on the body. Effective for pain management, stress reduction, and overall wellness.'
        ],
        [
            'name' => 'Physical Therapy',
            'description' => 'Rehabilitation and strengthening exercises to restore mobility and function. Our physical therapists create customized treatment plans to help you recover from injury and prevent future problems.'
        ],
        [
            'name' => 'Holistic Health',
            'description' => 'Comprehensive approach to wellness that addresses the whole person - mind, body, and spirit. We integrate multiple healing modalities for optimal health outcomes.'
        ],
        [
            'name' => 'Pain Management',
            'description' => 'Comprehensive pain relief strategies using natural, non-invasive methods. We help you manage chronic pain conditions and improve your quality of life without relying on medications.'
        ],
        [
            'name' => 'Sports Medicine',
            'description' => 'Specialized treatment for athletic injuries and performance optimization. Our sports medicine experts help athletes of all levels prevent injuries and enhance performance.'
        ],
        [
            'name' => 'Wellness Coaching',
            'description' => 'Personalized guidance to help you achieve your health and wellness goals. Our coaches provide ongoing support and accountability for lifestyle changes.'
        ],
        [
            'name' => 'Concussion Treatment',
            'description' => 'Specialized care for head injuries and recovery. Our comprehensive approach helps patients safely return to normal activities after concussion or traumatic brain injury.'
        ]
    ];
}

// Get services and sort alphabetically
$services = get_wellness_services();
usort($services, function($a, $b) {
    return strcmp($a['name'], $b['name']);
});

// Helper function to create anchor-friendly IDs (no spaces)
function create_anchor_id($name) {
    return strtolower(str_replace([' ', '&', ',', '.'], ['', 'and', '', ''], $name));
}
?>

<style>
    .services-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
    }
    
    .services-title {
        color: var(--primary-green, #8bc34a);
        text-align: center;
        margin-bottom: 40px;
        font-size: 2.5rem;
        font-weight: 700;
    }
    
    .service-item {
        display: flex;
        align-items: flex-start;
        margin-bottom: 30px;
        padding: 25px;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        background: white;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .service-item:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }
    
    .service-image {
        width: 150px;
        height: 150px;
        margin-right: 25px;
        flex-shrink: 0;
        border: 2px solid #ddd;
        border-radius: 8px;
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 12px;
        text-align: center;
        position: relative;
        overflow: hidden;
    }
    
    .service-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 6px;
    }
    
    .service-content {
        flex: 1;
    }
    
    .service-title {
        color: var(--primary-green, #8bc34a);
        font-size: 1.6rem;
        margin-bottom: 15px;
        font-weight: 700;
    }
    
    .service-description {
        color: #555;
        font-size: 1.1rem;
        line-height: 1.6;
        margin: 0;
    }
    
    /* Service icon placeholders */
    .service-image::before {
        content: "🏥";
        font-size: 3rem;
        opacity: 0.3;
    }
    
    .service-item[data-service="chiropractic"] .service-image::before { content: "🦴"; }
    .service-item[data-service="massage"] .service-image::before { content: "💆"; }
    .service-item[data-service="nutrition"] .service-image::before { content: "🥗"; }
    .service-item[data-service="acupuncture"] .service-image::before { content: "📍"; }
    .service-item[data-service="physical"] .service-image::before { content: "🏃"; }
    .service-item[data-service="holistic"] .service-image::before { content: "🧘"; }
    .service-item[data-service="pain"] .service-image::before { content: "⚡"; }
    .service-item[data-service="sports"] .service-image::before { content: "⚽"; }
    .service-item[data-service="wellness"] .service-image::before { content: "💚"; }
    .service-item[data-service="concussion"] .service-image::before { content: "🧠"; }
    
    @media (max-width: 768px) {
        .services-container {
            padding: 20px 15px;
        }
        
        .services-title {
            font-size: 2rem;
        }
        
        .service-item {
            flex-direction: column;
            padding: 20px;
        }
        
        .service-image {
            margin-right: 0;
            margin-bottom: 20px;
            align-self: center;
        }
        
        .service-title {
            font-size: 1.4rem;
            text-align: center;
        }
        
        .service-description {
            text-align: center;
        }
    }
    
    @media (max-width: 480px) {
        .service-image {
            width: 120px;
            height: 120px;
        }
        
        .services-title {
            font-size: 1.8rem;
        }
        
        .service-title {
            font-size: 1.3rem;
        }
    }
</style>

<div class="services-container">
    <h1 class="services-title">Our Services</h1>
    
    <?php foreach ($services as $service): 
        $anchor_id = create_anchor_id($service['name']);
        $service_key = strtolower(explode(' ', $service['name'])[0]); // First word for icon
    ?>
        <a name="<?php echo esc_attr($anchor_id); ?>"></a>
        <div class="service-item" id="<?php echo esc_attr($anchor_id); ?>" data-service="<?php echo esc_attr($service_key); ?>">
            <div class="service-image">
                <?php 
                // Try to load an image if it exists
                $image_name = strtolower(str_replace(' ', '-', $service['name']));
                $image_path = get_template_directory() . '/images/' . $image_name . '.jpg';
                $image_url = get_template_directory_uri() . '/images/' . $image_name . '.jpg';
                
                if (file_exists($image_path)): ?>
                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($service['name']); ?>">
                <?php endif; ?>
            </div>
            <div class="service-content">
                <h2 class="service-title"><?php echo esc_html($service['name']); ?></h2>
                <p class="service-description"><?php echo esc_html($service['description']); ?></p>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php get_footer(); ?>