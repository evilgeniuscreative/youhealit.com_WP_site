<?php
/* Template Name: Services Page */
?>
<?php 
get_header(); 

// Get existing services from your available_services array
global $available_services;

// Fallback if array doesn't exist
if (empty($available_services)) {
    $available_services = get_available_services();
}

// Sort services alphabetically by name
$services = $available_services;
if (!empty($services)) {
    usort($services, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
}

// Service icons mapping
$service_icons = [
    'acupuncture' => '📍',
    'chiropractic' => '🦴', 
    'concussion' => '🧠',
    'holistic' => '🧘',
    'massage' => '💆',
    'nutritional' => '🥗',
    'nutrition' => '🥗',
    'pain' => '⚡',
    'physical' => '🏃',
    'sports' => '⚽',
    'wellness' => '💚',
    'therapy' => '🩺',
    'care' => '🏥',
    'back' => '🦴',
    'spine' => '🦴',
    'injury' => '🩹'
];

function get_service_icon($title, $icons) {
    $title_lower = strtolower($title);
    foreach ($icons as $key => $icon) {
        if (strpos($title_lower, $key) !== false) {
            return $icon;
        }
    }
    return '🏥'; // Default icon
}
?>

<style>
    .services-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
    }
    
    .services-title {
        color: var(--primary-green, #8bc34a);
        text-align: center;
        margin-bottom: 40px;
        font-size: 2.5rem;
        font-weight: 700;
    }
    
    .service-item {
        display: flex;
        align-items: flex-start;
        margin-bottom: 30px;
        padding: 25px;
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        background: white;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        scroll-margin-top: 100px; /* Offset for sticky header */
    }
    
    .service-item:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }
    
    /* Highlight targeted service */
    .service-item:target {
        border-color: var(--primary-green, #8bc34a);
        box-shadow: 0 8px 25px rgba(139, 195, 74, 0.2);
        transform: translateY(-3px);
    }
    
    .service-image {
        width: 150px;
        height: 150px;
        margin-right: 25px;
        flex-shrink: 0;
        border: 2px solid #ddd;
        border-radius: 8px;
        background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 3rem;
        position: relative;
        overflow: hidden;
    }
    
    .service-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 6px;
    }
    
    .service-content {
        flex: 1;
    }
    
    .service-title {
        color: var(--primary-green, #8bc34a);
        font-size: 1.6rem;
        margin-bottom: 15px;
        font-weight: 700;
        scroll-margin-top: 100px; /* Offset for sticky header */
    }
    
    .service-description {
        color: #555;
        font-size: 1.1rem;
        line-height: 1.6;
        margin: 0;
    }
    
    .no-services {
        text-align: center;
        padding: 60px 20px;
        color: #666;
    }
    
    @media (max-width: 768px) {
        .services-container {
            padding: 20px 15px;
        }
        
        .services-title {
            font-size: 2rem;
        }
        
        .service-item {
            flex-direction: column;
            padding: 20px;
        }
        
        .service-image {
            margin-right: 0;
            margin-bottom: 20px;
            align-self: center;
        }
        
        .service-title {
            font-size: 1.4rem;
            text-align: center;
        }
        
        .service-description {
            text-align: center;
        }
    }
</style>

<div class="services-container">
    <h1 class="services-title">Our Services</h1>
    
    <?php if (!empty($services)): ?>
        <?php foreach ($services as $service): 
            $anchor_id = create_anchor_id($service['name']);
            $icon = get_service_icon($service['name'], $service_icons);
            
            // Check if service has an image path
            $image_name = strtolower(str_replace(' ', '-', $service['name']));
            $image_path = get_template_directory() . '/images/' . $image_name . '.jpg';
            $image_url = get_template_directory_uri() . '/images/' . $image_name . '.jpg';
        ?>
            <a name="<?php echo esc_attr($anchor_id); ?>" id="<?php echo esc_attr($anchor_id); ?>"></a>
            <div class="service-item" id="service-<?php echo esc_attr($anchor_id); ?>">
                <div class="service-image">
                    <?php if (file_exists($image_path)): ?>
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($service['name']); ?>">
                    <?php else: ?>
                        <?php echo $icon; ?>
                    <?php endif; ?>
                </div>
                <div class="service-content">
                    <h2 class="service-title" id="title-<?php echo esc_attr($anchor_id); ?>"><?php echo esc_html($service['name']); ?></h2>
                    <div class="service-description">
                        <?php echo esc_html($service['description']); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-services">
            <h2>Services Coming Soon</h2>
            <p>We're currently updating our services information. Please check back soon or contact us directly for information about our available treatments.</p>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>